# Jagrati - Android App 

Jagrati-application is for accomplishing day-to-day task for volunteers and students.

## Features

The android app lets you:
- Take attendance of students, attendance record will update automatically.
- Past attendance can seen for individual student or whole of section.
- Student details and volunteer details.
- Quiz can created through the app for a particular class.
- Student enrolled in that particular class can give the quiz, details of answer submitted are given in student profile.

# Contributing Guidelines

- Fork the repo and clone it to your local machine.


