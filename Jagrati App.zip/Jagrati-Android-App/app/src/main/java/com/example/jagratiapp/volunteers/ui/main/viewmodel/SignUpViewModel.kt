package com.example.jagratiapp.volunteers.ui.main.viewmodel

import androidx.lifecycle.ViewModel

class SignUpViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}