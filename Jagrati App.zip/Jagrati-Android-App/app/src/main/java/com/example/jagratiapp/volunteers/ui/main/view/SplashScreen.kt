package com.example.jagratiapp.volunteers.ui.main.view

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.jagratiapp.R
import com.example.jagratiapp.databinding.SplashScreenFragmentBinding
import com.example.jagratiapp.volunteers.ui.main.viewmodel.SplashScreenViewModel

class SplashScreen : Fragment() {

    companion object {
        fun newInstance() = SplashScreen()
    }

    private lateinit var viewModel: SplashScreenViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val binding : SplashScreenFragmentBinding =
                DataBindingUtil.inflate(inflater,R.layout.splash_screen_fragment,container,false)
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(SplashScreenViewModel::class.java)
        // TODO: Use the ViewModel
    }

}