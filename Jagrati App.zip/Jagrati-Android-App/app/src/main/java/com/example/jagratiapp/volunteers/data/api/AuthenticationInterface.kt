package com.example.jagratiapp.volunteers.data.api

interface AuthenticationInterface {
    fun getLogin()

}