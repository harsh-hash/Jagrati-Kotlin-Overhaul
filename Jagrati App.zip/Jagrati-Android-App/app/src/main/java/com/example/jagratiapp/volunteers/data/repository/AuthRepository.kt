package com.example.jagratiapp.volunteers.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class AuthRepository {
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private val users:LiveData<FirebaseUser> = LiveData<firebaseAuth.currentUser>
    var loggedOutLiveData:MutableLiveData<Boolean>? =null

    fun authRepo(){
        if (firebaseAuth.currentUser!=null)
        {
            users?.postValue(firebaseAuth.currentUser)
        }
    }

}