package com.example.jagratiapp.volunteers.data.model

data class LoggedUser(
        var name: String = ""
)